Forked from Chad Maron's code: https://github.com/cmaron/CS-7641-assignments.

Ensure that Python 3 is installed, along with the requirements in requirements.txt.
To run, enter 'python run_experiment.py --all'
